module MessagePack
  VERSION = "1.8.0"
  # Note for maintainers:
  #  Don't miss building/releasing the JRuby version (rake buld:java)
  #  See "How to build -java rubygems" in README for more details.
end
