# frozen_string_literal: true

require_relative "../bootsnap"

Bootsnap.default_setup
