#ifndef BOOTSNAP_H
#define BOOTSNAP_H 1

/* doesn't expose anything */

#endif /* BOOTSNAP_H */
