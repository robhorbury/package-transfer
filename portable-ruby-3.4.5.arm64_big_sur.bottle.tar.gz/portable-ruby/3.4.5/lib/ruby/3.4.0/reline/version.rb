module Reline
  VERSION = '0.6.0'
end
