# frozen_string_literal: true

module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.14.0'

end
