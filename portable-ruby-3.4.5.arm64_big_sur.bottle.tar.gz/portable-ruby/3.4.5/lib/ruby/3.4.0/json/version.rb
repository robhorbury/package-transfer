# frozen_string_literal: true

module JSON
  VERSION = '2.9.1'
end
